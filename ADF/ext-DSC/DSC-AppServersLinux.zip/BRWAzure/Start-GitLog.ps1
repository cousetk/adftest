function Start-GitLog
{
    git log --all --graph --decorate
}
new-alias -name glog -value Start-GitLog