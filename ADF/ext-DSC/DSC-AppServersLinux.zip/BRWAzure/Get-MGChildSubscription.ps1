
function Get-MGChildSubscription
{
    param (
        [parameter(ValueFromPipeline)]
        $Parent = ('019ba1bd-40cd-48bc-acfb-2f40a6e4eecb'),
        [int]$Level = 0,
        [string]$GrandParent
    )

    begin
    {
        if ($Parent.gettype().fullname -eq 'System.String')
        {
            $Parent = [pscustomobject]@{Name = $Parent ; DisplayName = 'TopLevel' }
        }
    }
    process
    {
        Foreach ($Child in $Parent)
        {
            $Level++
            Write-Verbose $Level
            Write-Verbose $Child.DisplayName
            Write-Verbose $Child.Name

            if ($Child.Type -eq '/subscriptions')
            {
                $Child | Add-Member -MemberType NoteProperty -Name 'MGDisplayName' -Value $GrandParent -PassThru
            }
            else 
            {
                Get-AzManagementGroup -GroupId $Child.Name -Expand | ForEach-Object {
                    if ($_.Children)
                    {
                
                        $_.Children | Get-MGChildSubscription -Level $Level -GrandParent $Child.DisplayName
                    }
                    else
                    {
                        Write-Verbose "no children [$($_.Children)]"
                    }
                }
            }
            $Level = 0
        }
    }
}


