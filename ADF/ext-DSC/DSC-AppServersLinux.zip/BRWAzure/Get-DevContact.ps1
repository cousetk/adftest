function Get-DevContact
{
    param (
        [Parameter(Mandatory = $true)]
        # [Parameter(ValueFromRemainingArguments)]
        [String[]]$Data,

        [String]$Separator = ';'
    )
    $data -split "`n" | Where-Object { $_.length -gt 1 } | ForEach-Object { $_ -split $Separator } |
        Select-Object -Unique | ForEach-Object { $_.trim().tolower() + '@microsoft.com' }
}