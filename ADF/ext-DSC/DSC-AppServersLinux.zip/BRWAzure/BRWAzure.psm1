# don't load in cloudshell
if (! (Test-Path -Path Env:/ACC_CLOUD))
{
    . $psScriptRoot\Install-Module.ps1
}
. $psScriptRoot\Remove-MYAZVMInstanceResource.ps1
. $psScriptRoot\Remove-MYAZVMInstanceParallel.ps1
. $psScriptRoot\Remove-MYAZVMExtensionParallel.ps1
. $psScriptRoot\Find-MYAZVMSize.ps1
. $psScriptRoot\Find-MYAZPublisherImageOffer.ps1
. $psScriptRoot\Find-MYAZAPIVersion.ps1
. $psScriptRoot\Find-MYAZPublisherExtensionOffer.ps1
. $psScriptRoot\Trace-MYAZDSCExtension.ps1
. $psScriptRoot\Stop-MYAZRGDP.ps1
. $psScriptRoot\Stop-MYAZDeploy.ps1
. $psScriptRoot\Get-MYAZDeploy.ps1
. $psScriptRoot\start-MYAZPolicyEvaluation.ps1
. $psScriptRoot\azl.ps1
. $psScriptRoot\azlad.ps1
. $psScriptRoot\AutoCompleter.ps1
. $psScriptRoot\Start-GitCommit.ps1
. $psScriptRoot\Invoke-FormatFile.ps1
. $psScriptRoot\Get-JWTtoken.ps1
. $psScriptRoot\GitMerge.ps1
. $psScriptRoot\Get-MyAzResourceID.ps1
. $psScriptRoot\Get-MyAzResourceURI.ps1
. $psScriptRoot\Get-MyAZJSONExport.ps1
. $psScriptRoot\cleantext.ps1
. $psScriptRoot\New-Escape.ps1
. $psScriptRoot\Start-AutomateMouseClick.ps1
. $psScriptRoot\Start-GitLog.ps1
. $psScriptRoot\Get-GitStatus.ps1
. $psScriptRoot\deploy.ps1
. $psScriptRoot\Switch-DSCModule.ps1
. $psScriptRoot\Start-BicepDownloadArtifact.ps1
. $psScriptRoot\Get-PESecurityInfo.ps1
. $psScriptRoot\Set-JITAccessPolicy.ps1
. $psScriptRoot\Get-DevContact.ps1
. $psScriptRoot\Get-MGChildSubscription.ps1
. $psScriptRoot\Get-RGInfo.ps1
Export-ModuleMember -function * -alias *
