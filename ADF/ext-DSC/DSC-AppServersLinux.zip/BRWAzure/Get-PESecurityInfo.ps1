
Function Get-PESecurityInfo
{
    param (
        [parameter(ValueFromPipeline)]
        [String]$Person = '.'
    )
    process
    {
        $d = Import-Csv 'C:\Users\benwilk\OneDrive - Microsoft\SCE-SRE\DSRE\securityKPI.csv'
        $d | Where-Object organization -EQ 'Platform Engineering' | Where-Object 'Assigned To' -Match $Person |
            Select-Object 'Assigned To', 'Service Name', 'Due Date',
            @{n = 'DetectedDate'; e = { [datetime]$_.'Detected On' } },
            @{n = 'AgeDays'; e = { New-TimeSpan -Start ([datetime]$_.'Detected On') -End (Get-Date) | ForEach-Object days } },
            'Team Group Name', Subscription*, Resource*, 'Remediation Level', 'Control ID',
            @{n = 'GuideLink'; e = { ($_.'Remediation Guide' -split "href=`"" | Select-Object -Index 1) -split '">' | Select-Object -First 1 }}
        }
}