function Start-GitCommit
{
    [CmdletBinding()]
    param (
        [Parameter(Position = 0, ValueFromRemainingArguments)]
        [Alias('M')]
        [String[]]$CommitMessage,

        [Switch]$Push,

        [string[]]$Exclude,

        [string[]]$Include = '.'

    )

    $message = $CommitMessage -join ' '
    git add $Include
    
    if ($Exclude)
    {
        git reset $Exclude
    }

    git commit -m $message
    if ($Push)
    {
        git push
    }
}
New-Alias -Name gcommit -Value Start-GitCommit -Force