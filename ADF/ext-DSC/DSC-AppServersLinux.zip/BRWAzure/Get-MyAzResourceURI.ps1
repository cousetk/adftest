function Get-MyAzResourceURI
{
    param (
        $rgName,
        $Name,
        $type,
        [validateset('providers', 'resources')]
        [string]$queryType = 'providers'
    )

    $n = $type -split '/' | Select-Object -First 1 | ForEach-Object { "/$_" }
    $t = ($type -split '/' | Select-Object -Skip 1) -join '/'
    $sub = Get-AzContext | ForEach-Object Subscription | ForEach-Object ID
    $type = $t -split '/' | Where-Object { $_ } | ForEach-Object { "/$_" }
    if (! $type) { $type = $null, $null, $null }
    $Names = $name -split '/' | Where-Object { $_ } | ForEach-Object { "/$_" }
    if (! $names) { $names = $null, $null, $null }
    'https://management.azure.com/subscriptions/{0}/resourceGroups/{1}/{2}/{3}{4}{5}{6}{7}{8}{9}' -f $sub, $rgName, $queryType, $n, $type[0], $Names[0], $type[1], $Names[1], $type[2], $Names[2]
}