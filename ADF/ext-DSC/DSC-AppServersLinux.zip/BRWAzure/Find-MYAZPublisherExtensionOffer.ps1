﻿<#
.Synopsis
   Find AZ Publishers, Offers and SKu's of Gallery Images
.DESCRIPTION
   Find AZ Publishers, Offers and SKu's of Gallery Images, this is required when deploying Virtual Machine Images, 
   It is recommended to use the 'Latest' for the version, instead of a specific version
.EXAMPLE
    Find-AZPublisherExtensionOffer -Location EASTUS2
 
#>

Function Find-MYAZPublisherExtensionOffer
{

    param (
        # Virtual Machine offerings are dependent on the region they are deployed
        $Location,
   
        $Publisher,
   
        $ImageType,
   
        $Sku 
    )

    Write-Verbose -Message "Searching for VM Sizes in region: $Location"
    try
    {
        if (! $Location)
        {
            $Location = Get-AzLocation | Out-GridView -OutputMode Single -Title 'Select the Location you want to deploy? Then click OK.' | ForEach-Object Location
        }
        if (! $Publisher)
        {
            $Publisher = Get-AzVMImagePublisher -Location $Location -EA Stop | Select-Object -Property PublisherName, Location |
                Out-GridView -OutputMode Single -Title 'Select the Publisher for your Image? Then click OK.' | ForEach-Object PublisherName
        }
        if (! $ImageType)
        {
            $ImageType = Get-AzVMExtensionImageType -PublisherName $Publisher -Location $Location -EA Stop | 
                Select-Object -Property PublisherName, Type, Location |
                Out-GridView -OutputMode Single -Title 'Select the ImageType? Then click OK.' | ForEach-Object Type
        }

        Get-AzVMExtensionImage -Location $location -Publisher $Publisher -Type $ImageType -EA Stop | 
            Select-Object -Property Version, Type, PublisherName, Location

    }
    Catch
    {
        Switch -Regex ( $_ )
        {
            'location' { Write-Warning -Message $_ }
            'Publisher' { Write-Warning -Message "Publisher '$Publisher' does not exist" }
            'extension' { Write-Warning -Message "ImageType '$ImageType' does not exist" }
            Default { Write-Warning -Message $_ }
        }
    }
}