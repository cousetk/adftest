function Start-AutomateMouseClick
{
    param (
        $y = 987,
        
        $x = 4961,
        
        $AmounttoMove = 55,

        [ValidateRange(1,4)]
        $timeBetweenClicks = 2
    )

    $signature = @'
[DllImport("user32.dll",CharSet=CharSet.Auto,CallingConvention=CallingConvention.StdCall)]
public static extern void mouse_event(long dwFlags, long dx, long dy, long cButtons, long dwExtraInfo);
'@

    $SendMouseClick = Add-Type -MemberDefinition $signature -Name 'Win32MouseEventNew' -Namespace Win32Functions -PassThru

    Add-Type -AssemblyName System.Windows.Forms

    while ($true)
    {
        $y -= $AmounttoMove
        $mouse = [System.Windows.Forms.Cursor]::Position = New-Object System.Drawing.Point($x, $y)
        Start-Sleep -sec $timeBetweenClicks
        
        #  left mouse down
        $SendMouseClick::mouse_event(0x00000002, 0, 0, 0, 0); 

        # left mouse up
        $SendMouseClick::mouse_event(0x00000004, 0, 0, 0, 0)
    }
}

function Get-CursorStartPosition
{
    while ($true)
    {
        [System.Windows.Forms.Cursor]::Position
        Start-Sleep -Seconds 3
    }
}
