Function Get-RGInfo
{
    param (
        [parameter(ValueFromPipeline)]
        $Subs,

        [string]
        $RGName = '.'
    )

    process
    {
        $Subs | ForEach-Object {
            $Name = $_.Name
            $DN = $_.DisplayName
            $MG = $_.MGDisplayName
            $c = Set-AzContext -SubscriptionId $Name
            $contact = Get-AzSecurityContact
            Get-AzResourceGroup | Where-Object Name -Match $RGName -EA 0 | Select-Object @{n = 'Service'; e = { $MG } },
            @{n = 'SubscriptionId'; e = { $Name } }, @{n = 'SubscriptionName'; e = { $DN } },
            ResourceId, @{n = 'Contact'; e = { $contact.Name } }, @{n = 'Email'; e = { $contact.Email } }
        }
    }
}