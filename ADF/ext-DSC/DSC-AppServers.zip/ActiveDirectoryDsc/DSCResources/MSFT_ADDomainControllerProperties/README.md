# Description

This resource enforces the single instance properties of a domain controller.
*Properties that must always have a value, but the value can be changed.*

## Requirements

* Target machine must be running Windows Server 2008 R2 or later.
